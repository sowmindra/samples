var otds_customization_enabled = true;
var otds_custom_dark_color = '#2ea5fd';
var otds_custom_medium_color = '#40c87f';
var otds_custom_light_color = '#ffffff';

function validateAuthCode() {
  if (!/^[0-9]{6,6}$/.test($('#otds_auth_code').val())) {
    alert('Please match the requested format: 6 digit numeric code.');
    return false;
  }

  return true;
}

$(document)
  .ready(function _onDocumentReady() {
    var loginError = $('#ot-core-home .login-error');
    var remMeCheckBoxText = $('label[for="otds_no_prompt_code"] .checkbox-text');
    var copyLink = $('#copy-qr-code a');
    var baseUrl =$('#hiddenBaseUrl').val();
    var twoFASetupList = $('.two-fa-step');
    var elementsToRemove = [
      $('#otds_auth_code_clearer')
    ];

    $('link[rel="shortcut icon"]').attr('href', baseUrl + '/favicon.ico');

    if (twoFASetupList.length === 1) {
      twoFASetupList.addClass('none-list-style');
    }

    copyLink.click(function() {
      var el = document.getElementById('secret-key');
      select_all_and_copy(el);
    });

    if(remMeCheckBoxText) {
      remMeCheckBoxText.text('Remember my device');
    }

    elementsToRemove
      .forEach(function _removeElements(element) {
        element.remove();
      });
  });
